<?php
$nom=$_POST['nombre'];
$apa=$_POST['apa'];
$ama=$_POST['ama'];
$id=$_POST['id'];
$cor=$_POST['email'];
$cla=$_POST['clave'];
$con=mysqli_connect("localhost","id5798215_rojo","12523916","id5798215_proesco") or die("error de conexion");
mysqli_query($con,"UPDATE tutor SET Nom_tutor='$nom',Ap_pat_tutor='$apa',Ap_mat_tutor='$ama',Correo_Tutor='$cor' where Id_Tutor='$id'")
    or die("error en actualizar ".mysqli_error($con));
mysqli_close($con);
header('Location: phpCata.php');
?>

<?php
$cor=$_POST['correo'];
$cos=$_POST['con'];
if($cor=='Pro@Esco.com' and $cos=='12523916'){
	    header('Location: catalogos.html');
}else{
    header('Location: ../mensaje2.html');
}
?>